package com.android.elements.assignment

import com.android.elements.assignment.base.getCelsiusTemperature
import com.android.elements.assignment.base.getCurrentDateTime
import org.junit.Assert
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class ExtensionsTest {

    companion object {
        const val EXPECTED_TIME = "2021-09-01 12:00:00"
        const val EXPECTED_TEMP_1 = "27.69"
        const val EXPECTED_TEMP_2 = "21.15"
        const val EXPECTED_TEMP_3 = "294.3"
    }

    @Test
    fun testCurrentDateTime() {
        val time = getCurrentDateTime("2021-09-01T12:00:00+00:00")
        Assert.assertEquals(EXPECTED_TIME, time)
    }

    @Test
    fun testConvertFahrenheitToCelsius() {
        val result = getCelsiusTemperature("81.84".toFloat(), "F")
        Assert.assertEquals(EXPECTED_TEMP_1, result)
    }

    @Test
    fun testConvertKelvinToCelsius() {
        val result = getCelsiusTemperature("294.3".toFloat(), "K")
        Assert.assertEquals(EXPECTED_TEMP_2, result)
    }

    @Test
    fun testConvertCelsiusToCelsius() {
        val result = getCelsiusTemperature("294.3".toFloat(), "C")
        Assert.assertEquals(EXPECTED_TEMP_3, result)
    }
}
