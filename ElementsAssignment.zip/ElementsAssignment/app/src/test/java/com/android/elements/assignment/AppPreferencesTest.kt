package com.android.elements.assignment

import android.content.Context
import com.android.elements.assignment.base.AppPreferences
import io.mockk.MockKAnnotations
import io.mockk.every
import io.mockk.impl.annotations.MockK
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class AppPreferencesTest {

    @MockK(relaxed = true)
    private lateinit var context: Context

    @MockK(relaxed = true)
    private lateinit var appPreferences: AppPreferences

    @Before
    fun init() {
        MockKAnnotations.init(this, relaxUnitFun = true)
    }

    @Test
    fun checkIfCityDetailsDownloadedTrue() {
        every { appPreferences.checkIfCityDetailsDownloaded(context) }.returns(true)
        Assert.assertEquals(true, appPreferences.checkIfCityDetailsDownloaded(context))
    }

    @Test
    fun checkIfCityDetailsDownloadedFalse() {
        every { appPreferences.checkIfCityDetailsDownloaded(context) }.returns(false)
        Assert.assertEquals(false, appPreferences.checkIfCityDetailsDownloaded(context))
    }
}
