package com.android.elements.assignment

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.android.elements.assignment.home.data.City
import com.android.elements.assignment.home.data.CityDetailApiStatus
import com.android.elements.assignment.home.db.CityDetailModel
import com.android.elements.assignment.home.repo.DBRepository
import com.android.elements.assignment.home.repo.MainRepository
import com.android.elements.assignment.home.repo.RemoteDataRepo
import com.android.elements.assignment.home.viewmodel.CityDetailViewModel
import io.mockk.MockKAnnotations
import io.mockk.coEvery
import io.mockk.impl.annotations.MockK
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestCoroutineDispatcher
import kotlinx.coroutines.test.TestCoroutineScope
import kotlinx.coroutines.test.runBlockingTest
import kotlinx.coroutines.test.setMain
import org.junit.*
import org.junit.runner.RunWith
import org.mockito.junit.MockitoJUnitRunner

@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class CityDetailViewModelTest {

    @get:Rule
    var instantRule = InstantTaskExecutorRule()

    private val testDispatcher = TestCoroutineDispatcher()

    private val testScope = TestCoroutineScope(testDispatcher)

    @MockK(relaxed = true)
    private lateinit var mainRepo: MainRepository

    @MockK(relaxed = true)
    private lateinit var remoteDataRepo: RemoteDataRepo

    @MockK(relaxed = true)
    private lateinit var dbRepository: DBRepository
    private lateinit var cityDetailViewModel: CityDetailViewModel

    private val fakeSuccessDataResult = listOf<CityDetailModel>(
        CityDetailModel(
            123, "TEST_DATE",
            City("TEST_NAME", "TEST_PICTURE"),
            "TEST_TEMP_TYPE", "TEST_TEMP"
        )
    )

    private val fakeCityList = listOf<String>("TEST_1, TEST_2, TEST_3")


    companion object {
        private const val ERROR_MESSAGE = "Error fetching picture detail"

    }

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        MockKAnnotations.init(this, relaxUnitFun = true)
        cityDetailViewModel = CityDetailViewModel(mainRepo)
    }

    @After
    fun tearDown() {
        testDispatcher.cleanupTestCoroutines()
    }

    @Test
    fun fetchCityDetailListFromNetworkSuccess() {

        runBlockingTest {
            testScope.launch(Dispatchers.IO) {
                coEvery { dbRepository.getAllCityDetails() } returns fakeCityList

                // make a call to fetch the city details from Network
                cityDetailViewModel.getCityDetailListFromNetwork()

                cityDetailViewModel.cityDetailLiveData.observeForever {
                    if (it !is CityDetailApiStatus.Loading) {
                        Assert.assertTrue((it is CityDetailApiStatus.Success))
                        val response = it as CityDetailApiStatus.Success
                        val successResponse = response as List<String>
                        Assert.assertEquals(
                            fakeCityList[0],
                            successResponse[0]
                        )
                        Assert.assertEquals(
                            fakeCityList[1],
                            successResponse[1]
                        )
                        Assert.assertEquals(
                            fakeCityList[2],
                            successResponse[2]
                        )
                    }
                }
            }
        }
    }

    @Test
    fun fetchCityDetailListFromNetworkFailure() {
        runBlockingTest {
            testScope.launch(Dispatchers.IO) {

                // make a call to fetch the city details from Network
                coEvery { mainRepo.getCityDetailsListFromNetwork() } throws Exception("Network Error")
                coEvery { dbRepository.getAllCityDetails() } returns fakeCityList

                cityDetailViewModel.getCityDetailListFromNetwork()
                cityDetailViewModel.cityDetailLiveData.observeForever {
                    if (it !is CityDetailApiStatus.Loading) {
                        Assert.assertTrue((it is CityDetailApiStatus.Error))
                        val errorResponse = it as CityDetailApiStatus.Error
                        Assert.assertEquals(
                            errorResponse.message,
                            ERROR_MESSAGE
                        )
                    }
                }
            }
        }
    }


    @Test
    fun fetchCityDetailListFromDbSuccess() {
        runBlockingTest {
            testScope.launch(Dispatchers.IO) {
                coEvery { mainRepo.getCityDetailsListDb() } returns fakeCityList
                coEvery { dbRepository.getAllCityDetails() } returns fakeCityList
                // make a call to fetch the city details from DB
                cityDetailViewModel.getCityDetailListFromDb()

                cityDetailViewModel.cityDetailLiveData.observeForever {
                    if (it !is CityDetailApiStatus.Loading) {
                        Assert.assertTrue((it is CityDetailApiStatus.Success))
                        val response = it as CityDetailApiStatus.Success
                        val successResponse = response as List<String>
                        Assert.assertEquals(
                            fakeCityList[0],
                            successResponse[0]
                        )
                        Assert.assertEquals(
                            fakeCityList[1],
                            successResponse[1]
                        )
                        Assert.assertEquals(
                            fakeCityList[2],
                            successResponse[2]
                        )
                    }
                }
            }
        }
    }


    @Test
    fun fetchCityDetailListFromDbFailure() {
        runBlockingTest {
            testScope.launch(Dispatchers.IO) {
                // make a call to fetch the city details from DB
                coEvery { mainRepo.getCityDetailsListDb() } throws Exception("DB Error")
                cityDetailViewModel.getCityDetailListFromDb()
                cityDetailViewModel.cityDetailLiveData.observeForever {
                    if (it !is CityDetailApiStatus.Loading) {
                        Assert.assertTrue((it is CityDetailApiStatus.Error))
                        val errorResponse = it as CityDetailApiStatus.Error
                        Assert.assertEquals(
                            errorResponse.message,
                            ERROR_MESSAGE
                        )
                    }
                }
            }
        }
    }

    @Test
    fun fetchSelectedCityDetailListFromDbSuccess() {
        runBlockingTest {
            testScope.launch(Dispatchers.IO) {
                coEvery { mainRepo.getSelectedCityDetails("TEST_NAME") } returns fakeSuccessDataResult
                coEvery { dbRepository.getSelectedCityDetails("TEST_NAME") } returns fakeSuccessDataResult
                // make a call to fetch the city details from DB
                cityDetailViewModel.getSelectedCityDetailsFromDb("TEST_NAME")

                cityDetailViewModel.cityDetailLiveData.observeForever {
                    if (it !is CityDetailApiStatus.Loading) {
                        Assert.assertTrue((it is CityDetailApiStatus.Success))
                        val response = it as CityDetailApiStatus.Success
                        val successResponse = (response.data as Array<CityDetailModel>)[0]
                        Assert.assertEquals(successResponse.temp, fakeSuccessDataResult[0].temp)
                        Assert.assertEquals(
                            successResponse.tempType,
                            fakeSuccessDataResult[0].tempType
                        )
                        Assert.assertEquals(successResponse.date, fakeSuccessDataResult[0].date)
                        Assert.assertEquals(
                            successResponse.city?.name,
                            fakeSuccessDataResult[0].city?.name
                        )
                        Assert.assertEquals(
                            successResponse.city?.picture,
                            fakeSuccessDataResult[0].city?.picture
                        )
                    }
                }
            }
        }
    }

    @Test
    fun fetchSelectedCityDetailListFromDbFailure() {
        runBlockingTest {
            testScope.launch(Dispatchers.IO) {
                // make a call to fetch the city details from DB
                coEvery { mainRepo.getSelectedCityDetails("TEST_NAME") } throws Exception("DB Error")
                cityDetailViewModel.getSelectedCityDetailsFromDb("TEST_NAME")
                cityDetailViewModel.cityDetailLiveData.observeForever {
                    if (it !is CityDetailApiStatus.Loading) {
                        Assert.assertTrue((it is CityDetailApiStatus.Error))
                        val errorResponse = it as CityDetailApiStatus.Error
                        Assert.assertEquals(
                            errorResponse.message,
                            ERROR_MESSAGE
                        )
                    }
                }
            }
        }
    }
}