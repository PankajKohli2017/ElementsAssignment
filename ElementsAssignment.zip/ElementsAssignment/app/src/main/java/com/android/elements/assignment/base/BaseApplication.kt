package com.android.elements.assignment.base

import com.android.elements.assignment.home.di.AppComponent
import com.android.elements.assignment.home.di.DaggerAppComponent
import dagger.android.AndroidInjector
import dagger.android.DaggerApplication

/**
 * Base application class
 * */
class BaseApplication : DaggerApplication() {
    //region VARIABLES
    private lateinit var appComponent: AppComponent
    //endregion

    //region METHODS
    override fun applicationInjector(): AndroidInjector<out DaggerApplication> {
        appComponent = DaggerAppComponent
            .builder()
            .application(this)
            .build()

        return appComponent
    }
    //endregion
}