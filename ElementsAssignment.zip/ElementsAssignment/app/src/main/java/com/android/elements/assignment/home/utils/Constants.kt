package com.android.elements.assignment.home.utils

/**
 * This singleton object contains all the constants value that will be used in application
 */
object Constants {
    const val baseUrl = "https://us-central1-mobile-assignment-server.cloudfunctions.net/"
    const val dbName = "elements.db"
    const val ITEM_BUNDLE = "item"
}