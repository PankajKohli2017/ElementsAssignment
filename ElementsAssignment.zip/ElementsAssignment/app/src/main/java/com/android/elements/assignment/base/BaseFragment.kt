package com.android.elements.assignment.base

import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.android.elements.assignment.R
import javax.inject.Inject

/**
 * Base class for the fragments
 * */
open class BaseFragment : Fragment() {

    //region VARIABLES
    @Inject
    lateinit var logger: Logger
    //endregion

    //region METHODS

    /**
     * Log message
     * @param message : Message to be logged
     * */
    fun logI(message: String) {
        logger.logI(message)
    }

    /**
     * Log message
     * @param message : Message to be logged
     * */
    fun logE(message: String) {
        logger.logE(message)
    }

    /**
     * Show Alert Dialog
     * @param title : Title to be shown
     * @param message : Message to be shown
     * */
    fun showAlert(title: String, message: String) {
        val builder = AlertDialog.Builder(requireContext())
        //set title for alert dialog
        builder.setTitle(title)
        //set message for alert dialog
        builder.setMessage(message)
        builder.setIcon(android.R.drawable.ic_dialog_alert)

        //performing positive action
        builder.setPositiveButton(R.string.ok) { dialogInterface, _ ->
            dialogInterface.dismiss()
        }
        // Create the AlertDialog
        val alertDialog: AlertDialog = builder.create()
        // Set other dialog properties
        alertDialog.setCancelable(true)
        alertDialog.show()
    }

    //endregion
}