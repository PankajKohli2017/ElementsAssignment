package com.android.elements.assignment.home.db

import androidx.room.Database
import androidx.room.RoomDatabase

/**
 * This class used to get the database object and [CityDetailModel].
 * It also handle database version and schema handling.
 */
@Database(entities = [CityDetailModel::class], version = 1, exportSchema = false)
abstract class DBHelper : RoomDatabase() {
    abstract fun getCityDetailsDAO(): CityDetailDAO
}