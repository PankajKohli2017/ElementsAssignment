package com.android.elements.assignment.home.repo

import com.android.elements.assignment.home.db.CityDetailDAO
import com.android.elements.assignment.home.db.CityDetailModel
import javax.inject.Inject

/**
 * Local DB repository to fetch and store the data locally.
 */
class DBRepository @Inject constructor(private val cityDetailDao: CityDetailDAO) {

    /**
     * Insert the City Details in DB
     * @param images : List<CityDetailModel> list of city details
     */
    fun insertAll(images: List<CityDetailModel>?) {
        if (images != null)
            cityDetailDao.insertAll(images)
    }

    /**
     * Get the all the city detail
     * @return List<CityDetailModel> : List of city detail
     */
    fun getAllCityDetails(): List<String> {
        return cityDetailDao.getAllCityDetails()
    }

    /**
     * Get the city details
     * @return List<CityDetailModel> : List of city detail
     */
    fun getSelectedCityDetails(name: String): List<CityDetailModel> {
        return cityDetailDao.getCityDetails(name)
    }

    /**
     * Get the city detail
     */
    fun deleteAllData() {
        cityDetailDao.deleteData()
    }
}