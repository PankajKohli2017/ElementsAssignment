package com.android.elements.assignment.home.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.android.elements.assignment.R
import com.android.elements.assignment.base.getCelsiusTemperature
import com.android.elements.assignment.home.db.CityDetailModel
import kotlinx.android.synthetic.main.layout_city_list_item.view.*
import javax.inject.Inject

class CityDetailAdapter @Inject constructor() : RecyclerView.Adapter<CityDetailAdapter.Holder>() {
    private lateinit var ctx: Context

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): Holder {
        ctx = parent.context
        return Holder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.layout_city_detail_list_item,
                parent,
                false
            )
        )
    }

    var cityList = listOf<CityDetailModel>()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = cityList[position]
        holder.cityNameTextView.text = "${
            item.temp?.let {
                item.tempType?.let { it1 ->
                    getCelsiusTemperature(
                        it.toFloat(),
                        it1
                    )
                }
            }
        } Celsius as on ${item.date}"
    }

    override fun getItemCount(): Int {
        return cityList.size
    }

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val cityNameTextView: TextView = view.cityName
    }
}