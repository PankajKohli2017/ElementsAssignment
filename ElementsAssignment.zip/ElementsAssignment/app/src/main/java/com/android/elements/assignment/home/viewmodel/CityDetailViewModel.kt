package com.android.elements.assignment.home.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.android.elements.assignment.base.TAG
import com.android.elements.assignment.base.getCurrentDateTime
import com.android.elements.assignment.home.data.CityDetailApiStatus
import com.android.elements.assignment.home.repo.MainRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * View model class for fetching the city details
 * */
class CityDetailViewModel @Inject constructor(private val mainRepository: MainRepository) :
    ViewModel() {

    //region Variables
    val cityDetailLiveData = MutableLiveData<CityDetailApiStatus<Any?>>()

    val selectedCityDetailLiveData = MutableLiveData<CityDetailApiStatus<Any?>>()
    //endregion

    //region LIFECYCLE

    /**
     * Get City Detail from Network
     * */
    fun getCityDetailListFromNetwork() {
        cityDetailLiveData.postValue(CityDetailApiStatus.Loading)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val apiResult = mainRepository.getCityDetailsListFromNetwork().asList()
                apiResult.onEach {
                    it.date = getCurrentDateTime(it.date!!)
                }
                mainRepository.storeLatestListInDb(apiResult)
                val listFromDb = mainRepository.getCityDetailsListDb()
                cityDetailLiveData.postValue(CityDetailApiStatus.Success(listFromDb))
            } catch (exception: Exception) {
                cityDetailLiveData.postValue(CityDetailApiStatus.Error(exception.message.toString()))
            }
        }
    }

    /**
     * Get City Detail from Local Db
     * */
    fun getCityDetailListFromDb() {
        cityDetailLiveData.postValue(CityDetailApiStatus.Loading)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val listFromDb = mainRepository.getCityDetailsListDb()
                cityDetailLiveData.postValue(CityDetailApiStatus.Success(listFromDb))
            } catch (exception: Exception) {
                cityDetailLiveData.postValue(CityDetailApiStatus.Error(exception.message.toString()))
            }
        }
    }

    /**
     * Get City Detail from Local Db
     * @param cityName: City name whose details needs to fetched.
     * */
    fun getSelectedCityDetailsFromDb(cityName: String) {
        selectedCityDetailLiveData.postValue(CityDetailApiStatus.Loading)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val listFromDb = mainRepository.getSelectedCityDetails(cityName)
                selectedCityDetailLiveData.postValue(CityDetailApiStatus.Success(listFromDb))
            } catch (exception: Exception) {
                selectedCityDetailLiveData.postValue(CityDetailApiStatus.Error(exception.message.toString()))
            }
        }
    }
    //endregion

    //region LIFECYCLE METHODS
    override fun onCleared() {
        super.onCleared()
        Log.d(TAG, "CityDetailViewModel destroyed!")
    }
    //endregion
}
