package com.android.elements.assignment.home.di

import com.android.elements.assignment.home.ui.CityDetailFragment
import com.android.elements.assignment.home.ui.CityListFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module(includes = [ViewModelModule::class])
abstract class FragmentBindingModule {
    @ContributesAndroidInjector
    abstract fun bindCityListFragment(): CityListFragment

    @ContributesAndroidInjector
    abstract fun bindCityDetailFragment(): CityDetailFragment
}