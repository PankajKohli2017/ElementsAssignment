package com.android.elements.assignment.home.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.android.elements.assignment.R
import com.android.elements.assignment.home.db.CityDetailModel
import kotlinx.android.synthetic.main.layout_city_list_item.view.*
import javax.inject.Inject

class CityListAdapter @Inject constructor() : RecyclerView.Adapter<CityListAdapter.Holder>() {
    private lateinit var ctx: Context
    lateinit var itemClick: OnItemClick


    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): Holder {
        ctx = parent.context
        return Holder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.layout_city_list_item,
                parent,
                false
            )
        ).listen { pos, _ ->
            cityList[pos].let { itemClick.onItemClick(it) }
        }
    }

    var cityList = listOf<String>()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    interface OnItemClick {
        fun onItemClick(cityName: String)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = cityList[position]
        holder.cityNameTextView.text = item
    }

    override fun getItemCount(): Int {
        return cityList.size
    }

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val cityNameTextView: TextView = view.cityName
    }
}

fun <T : RecyclerView.ViewHolder> T.listen(event: (position: Int, type: Int) -> Unit): T {
    itemView.setOnClickListener {
        event.invoke(adapterPosition, itemViewType)
    }
    return this
}