package com.android.elements.assignment.base

import android.content.Context
import android.content.SharedPreferences

/**
 * Preferences file to store  app preferences
 * */
object AppPreferences {
    //region Variables
    private const val PREFS_NAME = "elements_test"
    private const val CITY_DETAILS_DOWNLOADED = "city_details_downloaded"

    //endregion

    /**
     * Get Preferences instance
     * */
    private fun getPreferences(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Save Boolean in preference
     * */
    private fun saveBoolean(context: Context, key: String, value: Boolean) {
        val editor = getPreferences(context).edit()
        editor.putBoolean(key, value)
        editor.apply()
        editor.commit()
    }

    /**
     * Set the flag true that is city details are downloaded.
     * */
    fun setCityDetailsDownloadedTrue(context: Context) {
        saveBoolean(context, CITY_DETAILS_DOWNLOADED, true)
    }

    /**
     * check if the city details are downloaded
     * */
    fun checkIfCityDetailsDownloaded(context: Context): Boolean {
        return getPreferences(context).getBoolean(CITY_DETAILS_DOWNLOADED, false)
    }
}