package com.android.elements.assignment.base

import android.util.Log

/**
 * Logger class for the application
 * */
class Logger(private val debugVersion: Boolean) {

    //region METHODS
    fun logD(message: String) {
        if (debugVersion)
            Log.d(TAG, message)
    }

    fun logI(message: String) {
        if (debugVersion)
            Log.i(TAG, message)
    }

    fun logE(message: String) {
        if (debugVersion)
            Log.e(TAG, message)
    }
    //endregion
}