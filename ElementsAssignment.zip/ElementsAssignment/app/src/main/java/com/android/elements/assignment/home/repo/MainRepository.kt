package com.android.elements.assignment.home.repo

import com.android.elements.assignment.home.db.CityDetailModel
import javax.inject.Inject

/**
 * Main repository to fetch and store the data from network/local repo.
 */
class MainRepository @Inject
constructor(
    private val remoteRepository: RemoteDataRepo,
    private val dbRepository: DBRepository
) {

    /**
     * Get the city details from network
     * @return list of the City details.
     */
    suspend fun getCityDetailsListFromNetwork(): Array<CityDetailModel> {
        return remoteRepository.getCityDetailList()
    }

    /**
     * Get the city details from DB
     * @return list of the City details.
     */
    fun getCityDetailsListDb(): List<String> {
        return dbRepository.getAllCityDetails()
    }

    /**
     * Get selected city details from DB.
     * @return list of the City details.
     */
    fun getSelectedCityDetails(name: String): List<CityDetailModel> {
        return dbRepository.getSelectedCityDetails(name)
    }

    /**
     * Store the city details in DB
     * @param cityDetailsArray : City details array
     */
    fun storeLatestListInDb(cityDetailsArray: List<CityDetailModel>) {
        // delete previous data
        dbRepository.deleteAllData()
        // insert the new data
        dbRepository.insertAll(cityDetailsArray)
    }
}