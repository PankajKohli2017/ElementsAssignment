package com.android.elements.assignment.base

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import java.text.SimpleDateFormat

//region GENERIC EXTENSIONS
val Any.TAG: String
    get() {
        return javaClass.simpleName
    }

// Check if the device is connected to internet
fun Context.isNetworkConnected(): Boolean {
    val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        val networkCapabilities =
            connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
        networkCapabilities != null &&
                networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } else {
        val nInfo = connectivityManager.activeNetworkInfo
        nInfo != null && nInfo.isAvailable && nInfo.isConnected
    }
}

// get current date and time
fun Any.getCurrentDateTime(input: String): String {
    val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
    val date = inputFormat.parse(input)
    val outputDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    return outputDateFormat.format(date)
}

// convert fahrenheit to celsius
fun Any.convertFahrenheitToCelsius(input: Float): String {
    val result = (input - 32) / 1.8
    return String.format("%.2f", result)
}

// convert kelvin to celsius
fun Any.convertKelvinToCelsius(input: Float): String {
    val result = (input - 273.15)
    return String.format("%.2f", result)
}

// get the temperature in celsius
fun Any.getCelsiusTemperature(temperature: Float, type: String): String {
    return when (type) {
        "K" -> {
            convertKelvinToCelsius(temperature)
        }
        "F" -> {
            convertFahrenheitToCelsius(temperature)
        }
        else -> {
            temperature.toString()
        }
    }
}
//endregion
