package com.android.elements.assignment.home.ui

import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.observe
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.elements.assignment.R
import com.android.elements.assignment.base.BaseFragment
import com.android.elements.assignment.home.adapters.CityDetailAdapter
import com.android.elements.assignment.home.data.CityDetailApiStatus
import com.android.elements.assignment.home.db.CityDetailModel
import com.android.elements.assignment.home.di.obtainViewModel
import com.android.elements.assignment.home.utils.Constants.ITEM_BUNDLE
import com.android.elements.assignment.home.viewmodel.CityDetailViewModel
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import dagger.android.support.AndroidSupportInjection
import kotlinx.android.synthetic.main.fragment_city_detail.*
import javax.inject.Inject

/**
 * Fragment to show the detail of the cities
 * */
class CityDetailFragment : BaseFragment() {
    //region VARIABLES
    private lateinit var selectedCity: String

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory
    private lateinit var viewModel: CityDetailViewModel

    @Inject
    lateinit var adapter: CityDetailAdapter
    //endregion

    //region LIFECYCLE METHODS
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidSupportInjection.inject(this)
        arguments?.let {
            selectedCity = it.getString(ITEM_BUNDLE)!!
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_city_detail, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initializeViews()
        viewModel = viewModelFactory.obtainViewModel(this)
        viewModel.getSelectedCityDetailsFromDb(selectedCity)
    }

    override fun onStart() {
        super.onStart()
        viewModel.selectedCityDetailLiveData.observe(viewLifecycleOwner) { state ->
            checkResponse(state)
        }
    }

    override fun onStop() {
        super.onStop()
        viewModel.selectedCityDetailLiveData.removeObservers(viewLifecycleOwner)
    }
    //endregion

    //region METHODS
    private fun initializeViews() {
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter
        recyclerView.addItemDecoration(
            DividerItemDecoration(
                requireContext(),
                DividerItemDecoration.VERTICAL
            )
        )
    }

    private fun checkResponse(state: CityDetailApiStatus<Any?>) {
        when (state) {
            is CityDetailApiStatus.Success -> {
                logI("Success")
                // save the city details in preferences
                val cityDetails = state.data as List<CityDetailModel>
                initializeViews(cityDetails)
            }

            is CityDetailApiStatus.Loading -> {
                logI("Loading")
            }

            is CityDetailApiStatus.Error -> {
                logE("Error ${state.message}")
                showAlert(
                    getString(R.string.error_title),
                    getString(R.string.error_message_generic)
                )
            }
        }
    }

    private fun initializeViews(cityDetails: List<CityDetailModel>) {
        // set image
        progressCircular.visibility = View.VISIBLE
        cityDetails[0].city?.let {
            Glide.with(requireContext())
                .load(it.picture)
                .listener(object : RequestListener<Drawable> {
                    override fun onLoadFailed(
                        e: GlideException?,
                        model: Any?,
                        target: Target<Drawable>?,
                        isFirstResource: Boolean
                    ): Boolean {
                        logE("Error downloading image")
                        progressCircular.visibility = View.GONE
                        Toast.makeText(
                            requireContext(),
                            "Not able to download image. Please try again later.",
                            Toast.LENGTH_SHORT
                        ).show()
                        return false
                    }

                    override fun onResourceReady(
                        resource: Drawable?,
                        model: Any?,
                        target: Target<Drawable>?,
                        dataSource: DataSource?,
                        isFirstResource: Boolean
                    ): Boolean {
                        logE("Image downloaded successfully")
                        progressCircular.visibility = View.GONE
                        return false
                    }

                })
                .placeholder(R.drawable.ic_placeholder)
                .into(imageView)
        }

        // set the city
        cityName.text = selectedCity
        // set welcome message
        description.text = getString(R.string.welcome_message)

        // set adapter for temperature and time.
        adapter.cityList = cityDetails
    }
    //endregion
}