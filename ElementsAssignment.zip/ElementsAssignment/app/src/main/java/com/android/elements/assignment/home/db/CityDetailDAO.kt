package com.android.elements.assignment.home.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

/**
 * This class is used to do database operation on table "cityDetails"
 */
@Dao
interface CityDetailDAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(image: CityDetailModel)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(images: List<CityDetailModel>)

    @Query("SELECT DISTINCT name FROM cityDetails ORDER BY name ASC ")
    fun getAllCityDetails(): List<String>

    @Query("SELECT * FROM cityDetails WHERE name = :cityName ORDER BY date ASC")
    fun getCityDetails(cityName: String): List<CityDetailModel>

    @Query("DELETE FROM cityDetails")
    fun deleteData()
}