package com.android.elements.assignment.home.repo

import com.android.elements.assignment.home.db.CityDetailModel
import com.android.elements.assignment.home.network.GetCityWeatherListService
import com.android.elements.assignment.home.utils.Constants
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Inject

/**
 * Repo to fetch the city list with weather.
 * **/
class RemoteDataRepo @Inject constructor() {
    //region Variables
    private val service: GetCityWeatherListService
    //endregion

    init {
        // intercept HTTP client to add the API key
        val client = OkHttpClient.Builder()
            .build()
        val retrofit = Retrofit.Builder()
            .client(client)
            .baseUrl(Constants.baseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        service = retrofit.create(GetCityWeatherListService::class.java)
    }

    //region METHODS

    /**
     * Get the city list
     * **/
    suspend fun getCityDetailList(): Array<CityDetailModel> = service.getCityWeatherList()
    //endregion
}