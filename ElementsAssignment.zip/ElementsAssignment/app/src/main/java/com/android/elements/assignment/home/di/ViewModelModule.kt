package com.android.elements.assignment.home.di

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.android.elements.assignment.home.viewmodel.CityDetailViewModel
import dagger.Binds
import dagger.Module
import dagger.multibindings.IntoMap

@Module
abstract class ViewModelModule {

    @Binds
    abstract fun bindViewModelFactory(factory: ViewModelFactory): ViewModelProvider.Factory

    @Binds
    @IntoMap
    @ViewModelKey(CityDetailViewModel::class)
    abstract fun bindCityDetailViewModel(viewModel: CityDetailViewModel): ViewModel

}