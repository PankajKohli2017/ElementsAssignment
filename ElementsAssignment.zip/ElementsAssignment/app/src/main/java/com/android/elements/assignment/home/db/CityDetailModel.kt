package com.android.elements.assignment.home.db

import android.os.Parcelable
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.android.elements.assignment.home.data.City
import kotlinx.android.parcel.Parcelize

/**
 * Data class for the city Details API
 * */
@Parcelize
@Entity(tableName = "cityDetails")
data class CityDetailModel(
    @PrimaryKey(autoGenerate=true)
    val id: Long,
    var date: String?,
    @Embedded
    val city: City?,
    var tempType: String?,
    var temp: String?
) : Parcelable