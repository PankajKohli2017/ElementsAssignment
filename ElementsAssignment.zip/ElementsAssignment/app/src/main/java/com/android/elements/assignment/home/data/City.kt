package com.android.elements.assignment.home.data

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class City(
    val name: String?,
    val picture: String?
) : Parcelable