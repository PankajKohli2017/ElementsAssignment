package com.android.elements.assignment.home.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.observe
import androidx.navigation.Navigation
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.elements.assignment.R
import com.android.elements.assignment.base.AppPreferences
import com.android.elements.assignment.base.BaseFragment
import com.android.elements.assignment.base.isNetworkConnected
import com.android.elements.assignment.home.adapters.CityListAdapter
import com.android.elements.assignment.home.data.CityDetailApiStatus
import com.android.elements.assignment.home.di.obtainViewModel
import com.android.elements.assignment.home.utils.Constants.ITEM_BUNDLE
import com.android.elements.assignment.home.viewmodel.CityDetailViewModel
import dagger.android.support.AndroidSupportInjection
import kotlinx.android.synthetic.main.fragment_main.*
import javax.inject.Inject

/**
 * Fragment to show the list of the cities
 * */
class CityListFragment : BaseFragment(), CityListAdapter.OnItemClick {

    //region VARIABLES
    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    @Inject
    lateinit var adapter: CityListAdapter
    private lateinit var viewModel: CityDetailViewModel
    //endregion

    //region LIFECYCLE METHODS
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AndroidSupportInjection.inject(this)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_main, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = viewModelFactory.obtainViewModel(this)
        initializeViews()
        populateCityDetail()
    }


    override fun onStart() {
        super.onStart()
        viewModel.cityDetailLiveData.observe(viewLifecycleOwner) { state ->
            checkResponse(
                state
            )
        }
    }

    override fun onStop() {
        super.onStop()
        viewModel.cityDetailLiveData.removeObservers(viewLifecycleOwner)
    }

    private fun initializeViews() {
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter
        recyclerView.addItemDecoration(
            DividerItemDecoration(
                requireContext(),
                DividerItemDecoration.VERTICAL
            )
        )
        adapter.also { it.itemClick = this }

        refreshLayout.setOnRefreshListener {
            refreshCityDetailsFromNetwork()
        }
    }
    //endregion

    //region METHODS
    private fun populateCityDetail() {
        val isInternetAvailable = context?.isNetworkConnected()
        val isDataPresentInDb = AppPreferences.checkIfCityDetailsDownloaded(requireContext())
        if (isInternetAvailable == true) {
            // if the device is connected to internet fetch the data from network
            viewModel.getCityDetailListFromNetwork()
        } else {
            // if the device is offline and data is present in DB fetch the Data from DB.
            if (isDataPresentInDb) {
                viewModel.getCityDetailListFromDb()
            } else {
                showAlert(getString(R.string.error_title), getString(R.string.error_message))
            }
        }
    }

    private fun refreshCityDetailsFromNetwork() {
        val isInternetAvailable = context?.isNetworkConnected()
        if (isInternetAvailable == true) {
            // if the device is connected to internet fetch the data from network
            viewModel.getCityDetailListFromNetwork()
        } else {
            // if the device is offline and data is present in DB fetch the Data from DB.
            showAlert(getString(R.string.error_title), getString(R.string.error_message))
            refreshLayout.isRefreshing = false
        }
    }

    private fun checkResponse(state: CityDetailApiStatus<Any?>) {
        when (state) {
            is CityDetailApiStatus.Success -> {
                logI("Success")
                // save the city details in preferences
                if (refreshLayout.isRefreshing) {
                    Toast.makeText(
                        requireContext(),
                        "List refreshed successfully",
                        Toast.LENGTH_SHORT
                    ).show()
                    refreshLayout.isRefreshing = false
                }
                AppPreferences.setCityDetailsDownloadedTrue(requireContext())
                adapter.cityList = state.data as List<String>
            }

            is CityDetailApiStatus.Loading -> {
                logI("Loading")
            }

            is CityDetailApiStatus.Error -> {
                if (refreshLayout.isRefreshing) {
                    refreshLayout.isRefreshing = false
                }
                logE("Error ${state.message}")
                showAlert(
                    getString(R.string.error_title),
                    getString(R.string.error_message_generic)
                )
            }
        }
    }

    override fun onItemClick(cityDetail: String) {
        //show detail fragment
        Navigation.findNavController(recyclerView).navigate(
            R.id.cityDetailFragment,
            bundleOf(ITEM_BUNDLE to cityDetail)
        )
    }
    //endregion
}