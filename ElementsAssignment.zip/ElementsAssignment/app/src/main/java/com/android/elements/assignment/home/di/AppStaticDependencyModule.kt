package com.android.elements.assignment.home.di

import com.android.elements.assignment.BuildConfig
import com.android.elements.assignment.base.Logger
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
internal class AppStaticDependencyModule {
    @Provides
    @Singleton
    fun provideLoggerInstance(): Logger = Logger(BuildConfig.DEBUG)
}