package com.android.elements.assignment.home.di

import android.content.Context
import androidx.room.Room
import com.android.elements.assignment.home.db.CityDetailDAO
import com.android.elements.assignment.home.db.DBHelper
import com.android.elements.assignment.home.utils.Constants
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
class DBModule {
    @Singleton
    @Provides
    fun getCityDetailsDAO(context: Context): DBHelper {
        return Room.databaseBuilder(
            context,
            DBHelper::class.java, Constants.dbName
        )
            .fallbackToDestructiveMigration()
            .build()
    }

    @Singleton
    @Provides
    fun getDAO(imgDB: DBHelper): CityDetailDAO {
        return imgDB.getCityDetailsDAO()
    }
}