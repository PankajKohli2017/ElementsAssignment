package com.android.elements.assignment.home.data

/**
 * Status detail for city details API
 * */
sealed class CityDetailApiStatus<out T> {
    object Loading : CityDetailApiStatus<Any?>()
    data class Success<T>(val data: T?) : CityDetailApiStatus<T>()
    data class Error(val message: String) : CityDetailApiStatus<Any?>()
}