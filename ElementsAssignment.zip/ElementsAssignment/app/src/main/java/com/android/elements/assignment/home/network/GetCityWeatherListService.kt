package com.android.elements.assignment.home.network

import com.android.elements.assignment.home.db.CityDetailModel
import retrofit2.http.GET

/**
 * Retrofit interface for the City list
 * */
interface GetCityWeatherListService {

    /**
     * Get City weather list
     * */
    @GET("/weather")
    suspend fun getCityWeatherList(): Array<CityDetailModel>
}