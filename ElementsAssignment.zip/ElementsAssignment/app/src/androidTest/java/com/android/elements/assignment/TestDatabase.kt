package com.android.elements.assignment

import android.content.Context
import androidx.room.Room
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.android.elements.assignment.home.data.City
import com.android.elements.assignment.home.db.CityDetailDAO
import com.android.elements.assignment.home.db.CityDetailModel
import com.android.elements.assignment.home.db.DBHelper
import org.junit.After
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
open class TestDatabase {
    private lateinit var context: Context
    private lateinit var database: DBHelper
    private lateinit var dao: CityDetailDAO

    @Before
    fun initDb() {
        context = InstrumentationRegistry.getInstrumentation().context
        database = Room.inMemoryDatabaseBuilder(
            context,
            DBHelper::class.java
        ).build()
        dao = database.getCityDetailsDAO()
    }

    @Test
    fun testInsertAll() {
        dao.insertAll(
            listOf(
                getFakeCityModel(1, "TEST_1"),
                getFakeCityModel(2, "TEST_2"),
                getFakeCityModel(3, "TEST_3")
            )
        )
        assertTrue(dao.getAllCityDetails().size == 3)
    }


    private fun getFakeCityModel(id: Long, name: String): CityDetailModel {
        return CityDetailModel(
            id, "TEST_DATE",
            City(name, "TEST_PICTURE"),
            "TEST_TEMP_TYPE", "TEST_TEMP"
        )
    }

    @Test
    fun testSelectedCity() {
        dao.deleteData()
        dao.insertAll(
            listOf(
                getFakeCityModel(1, "TEST_1"),
                getFakeCityModel(2, "TEST_1"),
                getFakeCityModel(3, "TEST_1")
            )
        )
        assertTrue(dao.getCityDetails("TEST_1").size == 3)
    }

    @Test
    fun testRemoveAll() {
        dao.deleteData()
        dao.insertAll(
            listOf(
                getFakeCityModel(1, "TEST_1"),
                getFakeCityModel(2, "TEST_2"),
                getFakeCityModel(3, "TEST_3")
            )
        )
        dao.deleteData()
        assertTrue(dao.getAllCityDetails().isNullOrEmpty())
    }

    @After
    fun closeDb() {
        dao.deleteData()
        database.close()
    }
}